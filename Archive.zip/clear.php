<?php

require_once("classes/SessionManager.php");

$session = new SessionManager();

$session -> destroySession();


?>
